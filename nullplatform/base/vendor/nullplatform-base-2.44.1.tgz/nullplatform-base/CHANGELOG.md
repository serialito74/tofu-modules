# Changelog

## [2.44.1](https://github.com/nullplatform/helm-charts/compare/nullplatform-base-2.44.0...nullplatform-base-2.44.1) (2026-09-01)


### Bug Fixes

* **base:** default gatewayApiCrdRef to v1.3.0, matching Istio 1.27 ([88b2114](https://github.com/nullplatform/helm-charts/commit/88b211443ff1028414c5fbfb116b1cbf4e364510))
* **base:** force-conflicts on the Gateway API CRD apply ([3d0e28d](https://github.com/nullplatform/helm-charts/commit/3d0e28d9b5fdd058694ade6fd3533ff790b8ab94))
* **base:** make gateway API CRD ref configurable and reconcile on upgrade ([8ac08a6](https://github.com/nullplatform/helm-charts/commit/8ac08a670b82d261ed38c149e97da2aa12717998))

## [2.44.0](https://github.com/nullplatform/helm-charts/compare/nullplatform-base-2.43.2...nullplatform-base-2.44.0) (2026-08-12)


### Features

* **base:** bump logs controller image to v1.6.0 ([b948c54](https://github.com/nullplatform/helm-charts/commit/b948c5456e7bfacade57ae06ee62278af89635c7))
* **base:** expose the logs controller routing annotation ([2c89f9e](https://github.com/nullplatform/helm-charts/commit/2c89f9ef183bde767d009d169fb16dbec5e113d8))

## [2.43.2](https://github.com/nullplatform/helm-charts/compare/nullplatform-base-2.43.1...nullplatform-base-2.43.2) (2026-08-11)


### Bug Fixes

* **base:** omit the azure internal LB subnet annotation when unset ([cf1fa95](https://github.com/nullplatform/helm-charts/commit/cf1fa95051e32c496423ecd30a98b1ead142aef4))

## [2.43.1](https://github.com/nullplatform/helm-charts/compare/nullplatform-base-2.43.0...nullplatform-base-2.43.1) (2026-08-07)


### Bug Fixes

* **base:** gateway PodDisruptionBudgets select zero pods ([2b9f9cd](https://github.com/nullplatform/helm-charts/commit/2b9f9cd5f65269e4ce95536c563999916fda288b))
* **base:** stop the namespaces from deleting themselves on upgrade ([ca796ca](https://github.com/nullplatform/helm-charts/commit/ca796caa7be72fae0c2ec8b5cb9343f6758faa91))

## [2.43.0](https://github.com/nullplatform/helm-charts/compare/nullplatform-base-2.42.0...nullplatform-base-2.43.0) (2026-07-30)


### Features

* **base:** bump logs controller image to v1.5.0 ([afde2e7](https://github.com/nullplatform/helm-charts/commit/afde2e7ae9a51b75defe65e6fcba39c68f5808b8))

## [2.42.0](https://github.com/nullplatform/helm-charts/compare/nullplatform-base-2.41.0...nullplatform-base-2.42.0) (2026-07-16)


### Features

* **base:** support IRSA annotations on logs controller SA when cloudwatch enabled ([f9213dd](https://github.com/nullplatform/helm-charts/commit/f9213dd2e4c3703a7cc8c68f7d17e623e4e84bf3))

## [2.41.0](https://github.com/nullplatform/helm-charts/compare/nullplatform-base-2.40.1...nullplatform-base-2.41.0) (2026-06-24)


### Features

* **base:** support azure subnet annotation for public gateway ([c35d1ca](https://github.com/nullplatform/helm-charts/commit/c35d1ca5004135c6e578807a648c0eb640ea21df))

## [2.40.1](https://github.com/nullplatform/helm-charts/compare/nullplatform-base-2.40.0...nullplatform-base-2.40.1) (2026-05-21)


### Bug Fixes

* **base:** replace ensureLease init container with pre-install hook Job ([e172807](https://github.com/nullplatform/helm-charts/commit/e17280774a5daa903e7170bbf5db996476a0a1d4))

## [2.40.0](https://github.com/nullplatform/helm-charts/compare/nullplatform-base-2.39.0...nullplatform-base-2.40.0) (2026-05-18)


### Features

* new release of logs controller ([eae2486](https://github.com/nullplatform/helm-charts/commit/eae2486ce349de524656091a59ba8ba1a716e858))

## [2.39.0](https://github.com/nullplatform/helm-charts/compare/nullplatform-base-2.38.3...nullplatform-base-2.39.0) (2026-05-14)


### Features

* **base:** add per-provider log/metrics split and applicationLogs toggle ([ed6beb2](https://github.com/nullplatform/helm-charts/commit/ed6beb21aeceb3fc99f0f5407f6c164c1e655d17))


### Bug Fixes

* **base:** nil-safe guard for applicationLogs.enabled ([f37f7a3](https://github.com/nullplatform/helm-charts/commit/f37f7a392a3f75ad0d8358f6884920ba1736b3fd))
* **base:** use kindIs to correctly detect applicationLogs.enabled=false ([27d4e0b](https://github.com/nullplatform/helm-charts/commit/27d4e0baaefb26908f4f7a95ce2d05da6801450a))
* fix yaml lint spacing before comments in values.yaml ([a745328](https://github.com/nullplatform/helm-charts/commit/a74532854819d56d9c127f7df1bcf776415ddb97))

## [2.38.3](https://github.com/nullplatform/helm-charts/compare/nullplatform-base-2.38.2...nullplatform-base-2.38.3) (2026-04-28)


### Bug Fixes

* fix kubectl docker.io/bitnami/kubectl:latest ([edde9ad](https://github.com/nullplatform/helm-charts/commit/edde9ad8d0d683a4bb9d76999f646e76db01f518))

## [2.38.2](https://github.com/nullplatform/helm-charts/compare/nullplatform-base-2.38.1...nullplatform-base-2.38.2) (2026-04-22)


### Bug Fixes

* **base:** update bitnami/kubectl image tag from 1.31 to latest ([0257316](https://github.com/nullplatform/helm-charts/commit/025731610cc3df742bed88717961515e61fa5e92))

## [2.38.1](https://github.com/nullplatform/helm-charts/compare/nullplatform-base-2.38.0...nullplatform-base-2.38.1) (2026-04-21)


### Bug Fixes

* **base:** ensure metrics-extractor lease exists before log-controller starts ([7a8b5ce](https://github.com/nullplatform/helm-charts/commit/7a8b5ced3b3c9687a2eda6a2290ee5a58d00bca0))
* **base:** make ensure-lease init container optional via logging.ensureLease ([22222b0](https://github.com/nullplatform/helm-charts/commit/22222b091be657ed631a38bddb8e5e7409b46003))

## [2.38.0](https://github.com/nullplatform/helm-charts/compare/nullplatform-base-2.37.0...nullplatform-base-2.38.0) (2026-02-26)


### Features

* **base:** add features ti gateways deploys ([33e3d5a](https://github.com/nullplatform/helm-charts/commit/33e3d5a68250f6be21eaf7ac57e91e76936a13c0))

## [2.37.0](https://github.com/nullplatform/helm-charts/compare/nullplatform-base-2.36.0...nullplatform-base-2.37.0) (2026-02-26)


### Features

* add tolerations ([600641e](https://github.com/nullplatform/helm-charts/commit/600641e8380a4e3c96891865f370fdb4714bce03))
* **base:** add features ti gateways deploys ([33e3d5a](https://github.com/nullplatform/helm-charts/commit/33e3d5a68250f6be21eaf7ac57e91e76936a13c0))

## [2.37.0](https://github.com/nullplatform/helm-charts/compare/nullplatform-base-2.36.0...nullplatform-base-2.37.0) (2026-02-25)


### Features

* add tolerations ([600641e](https://github.com/nullplatform/helm-charts/commit/600641e8380a4e3c96891865f370fdb4714bce03))


## [2.36.0](https://github.com/nullplatform/helm-charts/compare/nullplatform-base-2.35.0...nullplatform-base-2.36.0) (2026-02-03)


### Features

* **charts-base:** delete hooks ([26d838d](https://github.com/nullplatform/helm-charts/commit/26d838d589783411e9d5c8ba0ac60f3268e9e0d1))


## [2.35.0](https://github.com/nullplatform/helm-charts/compare/nullplatform-base-2.34.0...nullplatform-base-2.35.0) (2026-01-30)


### Features

* **base:** add k3s to supported providers list ([46dbb76](https://github.com/nullplatform/helm-charts/commit/46dbb76678a7bc4e2ba31a0c3e389d4de7bb4994))


## [2.34.0](https://github.com/nullplatform/helm-charts/compare/nullplatform-base-2.33.2...nullplatform-base-2.34.0) (2026-01-30)


### Features

* **ci:** use centralized changelog-release workflow ([a90e4a1](https://github.com/nullplatform/helm-charts/commit/a90e4a17725f6833f953cc2dcfcb34fa29f212b0))



## [2.33.1](https://github.com/nullplatform/helm-charts/compare/nullplatform-base-2.33.0...nullplatform-base-2.33.1) (2026-01-28)


## [2.33.0](https://github.com/nullplatform/helm-charts/releases/tag/nullplatform-base-2.33.0) (2026-01-28)


### Features

* **helm-charts:** add new features to helm charts ([fb9af0a](https://github.com/nullplatform/helm-charts/commit/fb9af0aded702f87cb7b355aafb577b1b0d543da))
* **oci:** add support to oci ([c7e0b9f](https://github.com/nullplatform/helm-charts/commit/c7e0b9fd4e745c64e491e6cd0281249aea543d8d))
* **base:** add OCI/OKE gateway support with load balancer annotations ([b784b21](https://github.com/nullplatform/helm-charts/commit/b784b218d21b48a1cb62c3d1351d9acade6ac578))
* **base:** add custom configuration ([33cebf4](https://github.com/nullplatform/helm-charts/commit/33cebf4954de1d89c68104f70af0ed688d425c7d))
* **base:** add custom configuration ([459d7bb](https://github.com/nullplatform/helm-charts/commit/459d7bba173adce9193f71098a18e7d8f3eac352))
* **logs:** add fluent conf ([2cefe46](https://github.com/nullplatform/helm-charts/commit/2cefe465792c38deb0811d1ffcc6f08f660bbb64))
* **base:** add configmaps custom ([64b011b](https://github.com/nullplatform/helm-charts/commit/64b011b3daead45086420a48c06bb45752be05ac))
* **base:** add configmaps custom ([031ab83](https://github.com/nullplatform/helm-charts/commit/031ab8371a3244ab43c1339b4613eef67717cbe0))
* **base:** add selinux for aro ([1bc916a](https://github.com/nullplatform/helm-charts/commit/1bc916ae17100a6bae4f63527e446636acf7bf06))
* **helm-charts:** add aws cert-manager & chart-base ([bbda817](https://github.com/nullplatform/helm-charts/commit/bbda817e163588d4dda89e990ba9fbdf6a17f91b))
* **certmanager:** add private certificate ([89ee117](https://github.com/nullplatform/helm-charts/commit/89ee1172f2b13b060d6f4720d4a00bc96ac12bed))
* add support to aro ([a813bfb](https://github.com/nullplatform/helm-charts/commit/a813bfb1c5e6b7183bcbaea16bb555edb3915cb2))
* **base:** edit yaml podmonitor ([c0eb54c](https://github.com/nullplatform/helm-charts/commit/c0eb54c6557eb7a54a84eb2e537e126d79200733))
* **base:** add metadata namespace for prometheus ([ffbcee7](https://github.com/nullplatform/helm-charts/commit/ffbcee7e70856db674f4e38fe79eeef486d2ada8))
* **base:** add rbac and podmonitor for prometheus operator ([9000374](https://github.com/nullplatform/helm-charts/commit/90003742a4df3922cbbdaee59e14c4e95dad7ccc))
* **agent:** support agent by namespace ([a567739](https://github.com/nullplatform/helm-charts/commit/a567739fdad69f1e97e175ef3afdc4c04397ebaa))
* **base:** edit certifcate name for ingress controller internal ([79925be](https://github.com/nullplatform/helm-charts/commit/79925be7196fb9b783fb60a6ca4692763fd422ec))
* **aro:** disambiguate ingresses for internal/external ([0c50c5c](https://github.com/nullplatform/helm-charts/commit/0c50c5c2088d2e12ae882916cabca6eb75ac893d))
* **base:** add SecurityContextConstraints to ARO ([3a2a258](https://github.com/nullplatform/helm-charts/commit/3a2a258c60cf0c320cc057fe4d025c56e84596f7))
* edit values with ingresscontroler ([821945e](https://github.com/nullplatform/helm-charts/commit/821945edd6f9ae9873d8b58677b4de1d0c7de104))
* add private controller ([ec76c01](https://github.com/nullplatform/helm-charts/commit/ec76c0197e0e6bb43072d36c05b4b2b291054d04))
* **aro:** add logic for openshift ([cb948a2](https://github.com/nullplatform/helm-charts/commit/cb948a24601b687f8d56399dfa783185c1f73313))
* **istio-metrics:** Extract istio metrics into separate chart ([905e115](https://github.com/nullplatform/helm-charts/commit/905e1153939c47aa6e32d2b3cacd968c45676c9d))
* **base:** remove job ([faa6ee3](https://github.com/nullplatform/helm-charts/commit/faa6ee31b7d251ea4e4dd5e5c91fd00010c95dbd))
* **base:** Add Istio metrics mode as alternative to log controller ([f2ea251](https://github.com/nullplatform/helm-charts/commit/f2ea25190723d2798975661e52fe0add4d544ecb))
* **base:** make prometheus port annotation configurable ([a8ec8da](https://github.com/nullplatform/helm-charts/commit/a8ec8dad4cc83417bfe81c45cdedf779503b0638))
* **base:** add annotations for prometheus auto discovery ([be18456](https://github.com/nullplatform/helm-charts/commit/be18456429275fcf84d51da239600aac617ccb1a))
* make gateway annotations cloud-aware with loadBalancerType flag ([38d41c7](https://github.com/nullplatform/helm-charts/commit/38d41c7e3dbe45f736981e6e7ecfa9a626534a4a))
* **base:** GIT-0000 Improve service account configuration for hooks ([8f00eee](https://github.com/nullplatform/helm-charts/commit/8f00eeeefe8e90b236051e2a7b2a69e61c46e141))
* **agent:** resolve conflic ([d64fcb9](https://github.com/nullplatform/helm-charts/commit/d64fcb99f90a0bb35249323cbf454daa3f7799a9))
* **docs:** Improve docs and support install in k3s ([404d3ec](https://github.com/nullplatform/helm-charts/commit/404d3ec5956936fefa6deb92c4910123339605de))
* **agent:** [main] multiple agent installations ([11e8c62](https://github.com/nullplatform/helm-charts/commit/11e8c6249e79da5f7661f00e4170426a86842fbf))
* **base:** add cloudwatch configurations ([1300104](https://github.com/nullplatform/helm-charts/commit/13001046bf3cf49586b1a7dad840a689f649ad4f))
* **base:** BAC-1546 include resource limits to logs controller containers ([bf6a85e](https://github.com/nullplatform/helm-charts/commit/bf6a85e84d27390e4923f6e0a261015209a9c4c1))
* **base:** NULL-168 added possibility to specify IPs to gateways ([dc022b5](https://github.com/nullplatform/helm-charts/commit/dc022b5a46ae8563978279880e32b4d5fae52b09))
* **base:** NULL-147 use nullplatform apikey or provide a secret with the value inside ([30acb5c](https://github.com/nullplatform/helm-charts/commit/30acb5ce29ad03a909dd828525869a6087ae41c8))
* **base:** BAC-1276 semantic versioning enabled ([3848265](https://github.com/nullplatform/helm-charts/commit/3848265368d93299230d70682a2976d573ec9c92))


### Bug Fixes

* **helm-charts:** fix comments ([f61f8ed](https://github.com/nullplatform/helm-charts/commit/f61f8ed5e884ce8304384f78c9e79ccf7df0ccd4))
* **base:** use fully qualified image name for kubectl ([5fca77a](https://github.com/nullplatform/helm-charts/commit/5fca77a611495cb00d91cca25c5df774c03330e6))
* **base:** add security groups to gateways ([04553ed](https://github.com/nullplatform/helm-charts/commit/04553ed4a71cfeb73b382a404d6eb75a91c362fa))
* **chart-base:** add balancer name for aws ([68b36ec](https://github.com/nullplatform/helm-charts/commit/68b36ecb06b5318badcf8a2cec568efd778fe1e8))
* **base:** fix values tls name ([2331b60](https://github.com/nullplatform/helm-charts/commit/2331b603f0b6fb08a814f119b816641aa78a3997))
* **base-gateways:** add annottaion to LB use subnet private ([22cb988](https://github.com/nullplatform/helm-charts/commit/22cb9887b30356c03e6961e585ceb5f44d98889c))
* **base-gateways:** add annottaion to LB use subnet private ([ef740a2](https://github.com/nullplatform/helm-charts/commit/ef740a2b1164950280993b663f34c42580920e19))
* **chart-base:** disable http option ([0704ed9](https://github.com/nullplatform/helm-charts/commit/0704ed9e91cdb10323f03ad9a1ddecf7d982be2e))
* **chart-base:** fix annotation to aws gateways ([759c21d](https://github.com/nullplatform/helm-charts/commit/759c21d9870de0f11b3028069aa16b99edeca689))
* removed security context constraints for aro since they don't work ([ee1c033](https://github.com/nullplatform/helm-charts/commit/ee1c03350497dadecb9480bdb386e0727674dbb6))
* dnsManagementPolicy is now  Unmanaged ([5aebed0](https://github.com/nullplatform/helm-charts/commit/5aebed0a9b99d75947835981dc6591133d84f6bb))
* **base:** Honour nullplatform tools ns configuration ([a6c8740](https://github.com/nullplatform/helm-charts/commit/a6c87405500a37d17613f445157ba060b3d70eea))
* **base:** resolve installGatewayV2Crd serviceaccount timing issue ([c9d697f](https://github.com/nullplatform/helm-charts/commit/c9d697f52f766a01278d1fc9f8144d4fc3bf7a7d))
* **base:** BAC-1446 keep gateways on chart deletion and prevent creation if they are already created ([2a1e5eb](https://github.com/nullplatform/helm-charts/commit/2a1e5ebabd8bd970649120f48f4a6881c81873c9))
